fn main(){
    
    //let x = 5;
    //x=10;
    //x=10;
    
    //let mut y =10;
    //y=20;
    let x = 5;
    let x = x+1; //Nueva variable
    println!("el valor de x es: {}" , x);
    
    let entero: i32 =42;
    let flotante: f64=3.1416;
    let booleano:bool=true;
    let caracter: char = 'a';
    
    //tupla -> structs
    let firulais: (i32, f64, char)=(43, 3.1516, 'b');
    
    let arreglo: [i32; 3]=[1,2,3];
    
    println!("Tupla (firulais) forma 1: {:?}", firulais);
    
    println!("Tupla (firulais) forma 2: ({},{},{}", firulais.0, firulais.1, firulais.2);
    println!("Hello world!");
}